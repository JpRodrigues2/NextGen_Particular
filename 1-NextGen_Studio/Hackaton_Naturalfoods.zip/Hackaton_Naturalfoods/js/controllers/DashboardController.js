angular.module('gamificacaoApp', [])
.controller('DashboardController', function($scope, $http) {
  const jogadorId = localStorage.getItem("playerId") || "joaopedro"; // fallback para testes

  const req = {
    method: 'GET',
    url: `https://service2.funifier.com/v3/player/${jogadorId}/status`,
    headers: {
      "Authorization": "Bearer eyJhbGciOiJIUzUxMiIsImNhbGciOiJHWklQIn0.H4sIAAAAAAAAAD2LwQoCIRgGXyU8e2j9TaN7EHTsAeJb_RcESVG3WqJ3zwr2NgwzL4EczryIgzD77ejZQZGyk9UTgSwYLKSoLmXuSWH4K2KUm0cJjf_oOfLKaBhRvw-cS_Ot9et4WU7uXrqbK5dVpC4CejBYvTOkSBsp-Jl_wiiygzbvD3ZQkXOgAAAA.FR3y3sWGfdtXObKzZPPuLUAkIhbYeNuWG5ukclGbGPIP-hZXpXwbut0U0xodQqIslfqN0As2-oLukYnzsbkZZA",
      "Content-Type": "application/json"
    }
  };

  $http(req).then(
    function(response) {
      const data = response.data;

      $scope.jogador = {
        name: data.name,
        photo: data.image.medium.url, // usando imagem de tamanho médio
        coins: data.pointCategories.moedas || 0
      };
    },
    function(error) {
      console.error("Erro ao carregar dados do jogador:", error);
    }
  );
});
