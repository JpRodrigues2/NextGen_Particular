angular.module('rankingApp', [])
.controller('RankingController', ['$http', function($http) {
    var ctrl = this;
    ctrl.players = [];
    ctrl.loading = true;
    ctrl.error = false;
    
    ctrl.init = function() {
        var req = {
            method: 'POST',
            url: 'https://service2.funifier.com/v3/leaderboard/ETCl1mm/leader/aggregate?period=&live=true',
            headers: {
                "Authorization": "Bearer eyJhbGciOiJIUzUxMiIsImNhbGciOiJHWklQIn0.H4sIAAAAAAAAAD2LywrCMBAAf0X2nIPNY2O9CwWPfoBsky0EgilJqhbx340KvQ3DzAtoDmde4Qh42I-eHUkl7WT1pEhZYmIQUFyauSWZyV8pRrF75FD5j54jb0yVRirfh5xLy62263RZB3fPzS2F8yZSE4Fa0FltUKPpUQA_519AaTrV4_sD1hUt4qAAAAA.3QR45tIp37jydFd-9nqZDWwNVUDQY5NL8Z17GuBlc8WUwC2hnJrhqNwIHvYQSkC3ELpd97-GJhPqjo2I_HuyJw",
                "Content-Type": "application/json"
            },
            data: []
        };
        
        $http(req).then(
            function(response) {
                ctrl.loading = false;
                if (response.data && response.data.data && response.data.data.leaders) {
                    // Processa os dados da API
                    ctrl.players = response.data.data.leaders.map(function(leader, index) {
                        return {
                            name: leader.name || 'Jogador Anônimo',
                            score: leader.score || 0,
                            isCurrentUser: false // Você pode definir isso baseado no usuário atual
                        };
                    });
                    
                    // Limita a exibição para os 50 primeiros
                    if (ctrl.players.length > 50) {
                        ctrl.players = ctrl.players.slice(0, 50);
                    }
                }
            },
            function(err) {
                ctrl.loading = false;
                ctrl.error = true;
                console.error('Erro ao carregar ranking:', err);
                
                // Dados de exemplo para demonstração (remova em produção)
                ctrl.loadSampleData();
            }
        );
    };
    
    // Função para carregar dados de exemplo (apenas para demonstração)
    ctrl.loadSampleData = function() {
        ctrl.players = [
            { name: "Jogador Top", score: 9850, isCurrentUser: false },
            { name: "Segundo Lugar", score: 8720, isCurrentUser: false },
            { name: "Terceiro Colocado", score: 7650, isCurrentUser: false },
            { name: "Competidor Ativo", score: 6540, isCurrentUser: false },
            { name: "Você", score: 5430, isCurrentUser: true },
            { name: "Outro Jogador", score: 4320, isCurrentUser: false },
            { name: "Participante", score: 3210, isCurrentUser: false },
            { name: "Novato", score: 2100, isCurrentUser: false }
        ];
    };
    
    ctrl.init();
}]);