angular.module('gamificationApp')
.service('apiService', ['$http', function($http) {
    this.getPlayerStatus = function(token) {
        // Adicione logs para depuração
        console.log('Token sendo usado:', token);
        
        const req = {
            method: 'GET',
            url: 'https://service2.funifier.com/v3/player/status', // Removi o :id da URL
            headers: {
                "Authorization": "Bearer " + token,
                "Content-Type": "application/json"
            }
        };
        
        console.log('Requisição sendo enviada:', req);
        return $http(req);
    };
}]);